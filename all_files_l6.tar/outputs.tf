output "node1_container_id" {
  description = "Container ID on Node 1 (local Docker host)"
  value       = docker_container.ubuntu_node1.id
}

output "node2_container_id" {
  description = "Container ID on Node 2 (remote Docker host)"
  value       = docker_container.ubuntu_node2.id
}

output "node1_ssh_access" {
  description = "SSH command to access Node 1 container"
  value       = "ssh -p 2222 root@127.0.0.1"
}

output "node2_ssh_access" {
  description = "SSH command to access Node 2 container"
  value       = "ssh -p 2222 root@${var.node_ips[0]}"
}

output "node1_network_subnet" {
  description = "Cluster network subnet on Node 1"
  value       = docker_network.cluster_net_node1.ipam_config[*].subnet
}

output "node2_network_subnet" {
  description = "Cluster network subnet on Node 2"
  value       = docker_network.cluster_net_node2.ipam_config[*].subnet
}

