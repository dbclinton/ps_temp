variable "node_ips" {
  description = "IP addresses of the remote Docker nodes"
  type        = list(string)
  default     = ["10.0.3.10", "10.0.3.174"]
}

variable "ssh_public_key_path" {
  description = "Path to the SSH public key used to access containers"
  default     = "~/.ssh/id_ed25519.pub"
}

variable "ssh_user" {
  description = "SSH user for remote nodes"
  type        = string
  default     = "cloud_user"
}

variable "ssh_private_key_path" {
  description = "Path to the SSH private key"
  type        = string
  default     = "~/.ssh/id_ed25519"
}

variable "ssh_public_key" {
  default = "~/.ssh/id_ed25519.pub"
}

variable "docker_network_name" {
  description = "Name of the Docker overlay network"
  type        = string
  default     = "cluster_network"
}

variable "container_image" {
  description = "Docker image to use for the containers"
  type        = string
  default     = "ubuntu:24.04"
}

variable "ssh_port" {
  description = "SSH port for container access"
  type        = number
  default     = 22
}
